package com.example.p10

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.RequiresApi
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.hitsofttech.hisabi.p9.com.example.p9.Logininfo
import kotlinx.android.synthetic.main.activity_main3.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity3 : AppCompatActivity() {

    lateinit var photoanimation: AnimationDrawable
    lateinit var heartanimation: AnimationDrawable

    var myHour: Int = 0
    var myMinute: Int = 0
    var alarmtime: String?= null
    lateinit var ctime: String
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        Username.setText(Logininfo.Name)
        Email.setText(Logininfo.Email)
        Username1.setText(Logininfo.Name)
        Phone_Number.setText(Logininfo.Phoneno)
        City.setText(Logininfo.City)
        Email.setText(Logininfo.Email)

        Logout.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            Logininfo.logout()
        })




        setalarm.setOnClickListener(View.OnClickListener {
            showTimepiker()
        })

        val bottomNavigation: BottomNavigationView = findViewById(R.id.navigationView)
        bottomNavigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)


        photos_image.setBackgroundResource(R.drawable.heartanimation)
        heartanimation = photos_image.background as AnimationDrawable


        images_guni.setBackgroundResource(R.drawable.photonimation)
        photoanimation = images_guni.background as AnimationDrawable


    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus)
        {
            heartanimation.start()
            photoanimation.start()
        }
        else
        {
            heartanimation.stop()
            photoanimation.start()
        }
    }

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {

            R.id.note -> {

                val intent = Intent(this, notesActivity::class.java)
                startActivity(intent)

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    fun showTimepiker() {
        val cal = Calendar.getInstance()
        val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
            setalarm.text = SimpleDateFormat("HH:mm:ss a").format(cal.time)

            setAlarm(cal.timeInMillis, "Start")
        }



        TimePickerDialog(
            this,
            timeSetListener,
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            false
        ).show()


    }


    @RequiresApi(Build.VERSION_CODES.KITKAT)
    fun setAlarm(mill: Long, str: String) {
        val intent = Intent(this, broadcast::class.java)
        intent.putExtra("Service",str)
        val pendingIntent = PendingIntent.getBroadcast(applicationContext, 0, intent, 0)
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (str == "Start") {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                mill,
                pendingIntent

            )
        }
        else if(str == "Stop")
        {
            alarmManager.cancel(pendingIntent)
        }

    }
}