package com.example.p10

import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.hitsofttech.hisabi.p9.com.example.p9.Logininfo
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        if (IsLogin()) {
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)

        }
    }

    fun IsLogin(): Boolean {
        if (!Logininfo.userLogin) {
            this.window.apply {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    statusBarColor = Color.TRANSPARENT
                }
            }

            signup.setOnClickListener {
                signup()
            }

            return false
        }
        return true
    }

    fun signup()
    {
        if(user_EditText.text.toString().isEmpty() ||
            phone_EditText.text.toString().isEmpty() ||
            city_EditText.text.toString().isEmpty() ||
            email_EditText.text.toString().isEmpty() ||
            password_EditText.text.toString().isEmpty() ||
            confirmpassword_EditText.text.toString().isEmpty())
        {
            Toast.makeText(this,"Fields are blank",Toast.LENGTH_LONG).show()

        }

        else if(password_EditText.text.toString() != confirmpassword_EditText.text.toString())
        {
            Toast.makeText(this,"Password and confirm password are not same",Toast.LENGTH_LONG).show()
        }

        else if(user_EditText.text.toString().isNotEmpty()&&
            phone_EditText.text.toString().isNotEmpty() &&
            city_EditText.text.toString().isNotEmpty() &&
            email_EditText.text.toString().isNotEmpty() &&
            password_EditText.text.toString().isNotEmpty() &&
            confirmpassword_EditText.text.toString().isNotEmpty()) {

            Logininfo.Name = user_EditText.text.toString()
            Logininfo.City = city_EditText.text.toString()
            Logininfo.Phoneno = phone_EditText.text.toString()
            Logininfo.Password = password_EditText.text.toString()
            Logininfo.Email = email_EditText.text.toString()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    fun log(view: View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}
