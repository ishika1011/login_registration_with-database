package com.example.p10

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_notes.*
import kotlinx.android.synthetic.main.add_note.view.*
import kotlinx.android.synthetic.main.listview.view.*
import java.text.SimpleDateFormat
import java.util.*


class notesActivity : AppCompatActivity() {
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)
        val bottomNavigation: BottomNavigationView = findViewById(R.id.navigationView)
        bottomNavigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        val list_view = layoutInflater.inflate(R.layout.listview,null)
        val View1 = layoutInflater.inflate(R.layout.add_note,null)
        val set_alarm = View1.findViewById<Switch>(R.id.switch1)
        set_alarm.isChecked = true
        val timePicker = View1.findViewById<TimePicker>(R.id.timePicker)
        val dateFormat = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
        val currentDate = dateFormat.format(Date())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            timePicker.hour = Calendar.HOUR
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            timePicker.minute = Calendar.MINUTE
        }


        val plusBtnClk = { dialog: DialogInterface, which: Int ->

            val calendar = Calendar.getInstance()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                calendar.set(Calendar.HOUR_OF_DAY, timePicker.hour)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                calendar.set(Calendar.MINUTE,timePicker.minute)
            }

            val alarmtime=SimpleDateFormat("MMM,dd yyyy HH:mm a").format(calendar.time)
            setAlarm(calendar.timeInMillis, "Start")



            if (set_alarm.isChecked) {
                setAlarm(calendar.timeInMillis, "Start")
                note.addingarray(
                    note.idNote,
                    View1.notetitle_edittext.text.toString(),
                    View1.notesubtitle_edittext.text.toString(),
                    View1.notediscription_edittext.text.toString(),
                    currentDate,
                    alarmtime,
                    true
                )

            }
            else {
                setAlarm(calendar.timeInMillis, "Stop")
                note.addingarray(
                    note.idNote,
                    View1.notetitle_edittext.text.toString(),
                    View1.notesubtitle_edittext.text.toString(),
                    View1.notediscription_edittext.text.toString(),
                    currentDate,
                    null.toString(),
                    false
                )

            }

            val adapter = Noteadapter(this, note.arrayNote)
            list1.adapter = adapter


        }



        btn_plus.setOnClickListener(View.OnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setView(View1)
            builder.setTitle("Add note")
            builder.setCancelable(true);
            builder.setPositiveButton(
                "OK",
                DialogInterface.OnClickListener(function = plusBtnClk)
            )
            val alertDialog = builder.create()
            alertDialog.window!!.setLayout(600, 1000) //Controlling width and height.

            if (View1 != null) {
                val parentViewGroup = View1.parent as ViewGroup?
                parentViewGroup?.removeAllViews();
            }

            alertDialog.show()

        })



    }

    inner class Noteadapter: BaseAdapter {

        var listofnotes=ArrayList<note>()
        var context:Context?=null

        constructor(context: Context,listofnotes:ArrayList<note>):super(){
            this.listofnotes=listofnotes
            this.context=context
        }

        @RequiresApi(Build.VERSION_CODES.M)
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {


            val notesi = getItem(position) as note


            var inflator=context?.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater



            var view= inflator.inflate(R.layout.listview,null)
            view.titlenote.text=notesi.title
            view.subtitlenote.text=notesi.subtitle
            view.descriptionnote.text=notesi.descri
            view.timeanddate.text=notesi.modifiedTime

            if (notesi.alarm_time=="null")
            {
                view.timeofalarm.visibility=View.GONE
            }
            else {
                view.timeofalarm.text = "Reminder At :"+notesi.alarm_time
            }


            val view2 = layoutInflater.inflate(R.layout.add_note,null)



            view2.notetitle_edittext.setText(notesi.title)
            view2.notesubtitle_edittext.setText(notesi.subtitle)
            view2.notediscription_edittext.setText(notesi.descri)


            val positiveButtonClick2 = { dialog: DialogInterface, which: Int ->
                val calendar = Calendar.getInstance()
                val timePicker = view2.findViewById<TimePicker>(R.id.timePicker)
                calendar.set(Calendar.HOUR_OF_DAY, timePicker.hour)
                calendar.set(Calendar.MINUTE,timePicker.minute)

                val alarmtime=SimpleDateFormat("MMM,dd yyyy HH:mm a").format(calendar.time)

                val setalarm = view2.findViewById<Switch>(R.id.switch1)
                setalarm.isChecked = true
                val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
                val currentDate = sdf.format(Date())


                if (setalarm.isChecked) {
                    setAlarm(calendar.timeInMillis, "Start")
                    note.updatearray(
                        position,
                        note.idNote,
                        view2.notetitle_edittext.text.toString(),
                        view2.notesubtitle_edittext.text.toString(),
                        view2.notediscription_edittext.text.toString(),
                        currentDate,
                        alarmtime,
                        true
                    )

                }
                else {
                    note.updatearray(
                        position,
                        note.idNote,
                        view2.notetitle_edittext.text.toString(),
                        view2.notesubtitle_edittext.text.toString(),
                        view2.notediscription_edittext.text.toString(),
                        currentDate,
                        null.toString(),
                        false
                    )

                }

                val adapter = Noteadapter(context!!, note.arrayNote)
                list1.adapter = adapter

                if (view != null) {
                    val parentViewGroup = view.parent as ViewGroup?
                    parentViewGroup?.removeAllViews();
                }

            }




            view.imbutton1.setOnClickListener(View.OnClickListener {
                val builder = AlertDialog.Builder(context!!)
                builder.setView(view2)
                builder.setTitle("Edit note")
                builder.setCancelable(true);
                builder.setPositiveButton(
                    "OK",
                    DialogInterface.OnClickListener(function = positiveButtonClick2 as (DialogInterface, Int) -> Unit)

                )


                val alertDialog = builder.create()

                alertDialog.window!!.setLayout(600, 1000) //Controlling width and height.


                alertDialog.show()

            })



            view.del.setOnClickListener(View.OnClickListener {
                note.arrayNote.removeAt(position)
                parent?.removeViewInLayout(view);

            })


            return view

        }

        override fun getItem(position: Int): Any {
            return listofnotes[position]
        }

        override fun getItemId(position: Int): Long {
            return  position.toLong()
        }

        override fun getCount(): Int {
            return listofnotes.size
        }


    }

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {

            R.id.dash -> {
                val intent = Intent(this, MainActivity3::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }



    @RequiresApi(Build.VERSION_CODES.KITKAT)
    fun setAlarm(mill: Long, str: String) {
        val intent = Intent(this, broadcast::class.java)
        intent.putExtra("Service",str)
        val pendingIntent = PendingIntent.getBroadcast(applicationContext, 0, intent, 0)
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (str == "Start") {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                mill,
                pendingIntent

            )
        }
        else if(str == "Stop")
        {
            alarmManager.cancel(pendingIntent)
        }

    }
   // private fun notificationDialog(context: Context,cls: Class<*>,title: String,descri:String,note:note)
    //{
      //  val notificationManager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        //val NOTIFICATION_CHANNEL_ID = "hitsofttech"
       // if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
         //   val notificationChannel= NOTIFICATION_CHANNEL(NOTIFICATION_CHANNEL_ID,"LoginRegistration",NotificationManager.IMPORTANCE_HIGH)
           // notificationChannel.descri="LoginRegistration description"
          //  notificationChannel.enableLights(true)
           // notificationChannel.LightColor=Color.RED
           // notificationChannel.vibrationPattern=LongArrayOf(0,1000,500,1000)
           // notificationChannel.enableVibration(true)
           // notificationManager.createNotificationChannel(notificationChannel)
            
             //  }

    //}

}


