package com.example.p10

import android.app.AlarmManager
import android.app.IntentService
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.annotation.Nullable

@Suppress("DEPRECATION")
class alarm_service : IntentService("Service") {
    override fun onHandleIntent(@Nullable intent: Intent?) {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val alarmIntent = Intent(this, broadcast::class.java)
        val pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0)


    }
}