package com.hitsofttech.hisabi.p9.com.example.p9

class Logininfo {
    companion object{
        var Email:String=""
        var Password:String=""
        var Name:String=""
        var City:String=""
        var Phoneno:String=""
        var userLogin:Boolean= false
        fun Login(email:String,password:String):Boolean{
            userLogin=Email==email && password== Password
            return userLogin
        }
        fun logout()
        {
            userLogin=false
        }
    }
}