package com.example.p10


class note(
    private var id1: Int,
    var title: String,
    var subtitle: String,
    var descri: String,
    var modifiedTime: String,
    var alarm_time: String,
    var is_remainder: Boolean = false) {
    var id = noteIDGenerator()
    constructor(note: note) :
            this(
                note.id1,
                note.title,
                note.subtitle,
                note.descri,
                note.modifiedTime,
                note.alarm_time,
                note.is_remainder
            ) {
    }

    companion object {
        var idNote = 0
        fun noteIDGenerator(): Int {
            idNote++
            return idNote
        }

        val arrayNote: ArrayList<note> = ArrayList<note>()
        fun addingarray(
            id2: Int,
            str1: String,
            str2: String,
            str3: String,
            str4: String,
            str5: String,
            b: Boolean
        ) {
            noteIDGenerator()
            val a = note(id2, str1, str2, str3, str4, str5, b)
            arrayNote.add(a)
        }

        fun updatearray(
            position: Int,
            id2: Int,
            str1: String,
            str2: String,
            str3: String,
            str4: String,
            str5: String,
            b: Boolean
        )     {
            val a=note(id2, str1, str2, str3, str4,str5, b)
            arrayNote[position] = a;
        }




    }
}
