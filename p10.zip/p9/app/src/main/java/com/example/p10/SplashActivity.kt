package com.example.p10

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.AnimationDrawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import kotlinx.android.synthetic.main.activity_splash.*

class Splashactivity : AppCompatActivity(), Animation.AnimationListener {
    lateinit var logoanimation: AnimationDrawable
    lateinit var rotateanimation: Animation
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        this.window.apply {
            clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                statusBarColor = Color.TRANSPARENT
            }
        }

        imgguni.setBackgroundResource(R.drawable.logo_animation)
        logoanimation = imgguni.background as AnimationDrawable

        rotateanimation= AnimationUtils.loadAnimation(this,R.anim.rotate_animation)
        rotateanimation.setAnimationListener(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus)
        {
            logoanimation.start()
            imgguni.startAnimation(rotateanimation)
        }
        else
        {
            logoanimation.stop()
        }
    }

    override fun onAnimationRepeat(animation: Animation?) {

    }

    override fun onAnimationEnd(animation: Animation?) {
        val intent= Intent(this,MainActivity::class.java)
        startActivity(intent)
    }

    override fun onAnimationStart(animation: Animation?) {
    }
}