package com.example.p10

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer

class broadcast : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        var mp: MediaPlayer?=null

        if(intent!=null && context!=null) {
            val str1= intent.getStringExtra("Service")
            if(str1 == null){}
            else if(str1 == "Start" || str1=="Stop") {
                val intentService= Intent(context,alarm_service::class.java)
                intentService.putExtra("Service",intent.getStringExtra("Service"))
                if(str1=="Start") {
                    context.startService(intentService)
                    mp=MediaPlayer.create(context,R.raw.alarm);
                    mp?.start()
                }
                else if(str1=="Stop"){
                    context.stopService(intentService)
                }

            }
        }
    }
}



