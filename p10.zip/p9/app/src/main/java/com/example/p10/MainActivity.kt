package com.example.p10

import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.hitsofttech.hisabi.p9.com.example.p9.Logininfo
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (IsLogin()) {
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)

        }
    }

    fun IsLogin(): Boolean {
        if (!Logininfo.userLogin) {
            this.window.apply {
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    statusBarColor = Color.TRANSPARENT
                }
            }

            signup.setOnClickListener {
                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                finish()
            }
            tv_signup.setOnClickListener {
                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)
                finish()
            }

            Login.setOnClickListener(View.OnClickListener {
                login()
            })
            return false
        }
        return true
    }


    fun login()
    {

        if (email_EditText.text.toString().isEmpty() || password_EditText.text.toString().isEmpty())
        {
            Toast.makeText(this,"Entries are incomplete", Toast.LENGTH_LONG).show()

        }
        else if(email_EditText.text.toString() != Logininfo.Email && password_EditText.text.toString() != Logininfo.Password )
        {
            Toast.makeText(this,"Incorrect Email id or Password ",Toast.LENGTH_LONG).show()
        }

       else  if(Logininfo.Login(email_EditText.text.toString(),password_EditText.text.toString()))
        {
            if (email_EditText.text.toString().isNotEmpty() && password_EditText.text.toString().isNotEmpty()) {
                val intent = Intent(this, MainActivity3::class.java)
                startActivity(intent)
            }

        }
        else
        {
            val intent = Intent(this, MainActivity::class.java)

            Toast.makeText(this,"Incorrect Email id or Password", Toast.LENGTH_LONG).show()

        }

    }

    fun sign(view: View) {
        val intent = Intent(this, MainActivity2::class.java)
        startActivity(intent)
    }

}